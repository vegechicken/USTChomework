<template>
  　　<pdf src="./static/experiment.pdf"></pdf>
  　　</template>

　　<script>
  import pdf from 'vue-pdf'

  export default {
    components: {
      pdf
    }
  }
</script>
