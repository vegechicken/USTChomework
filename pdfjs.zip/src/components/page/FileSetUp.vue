<template>
    <a href="./static/web/viewer.html?file=原子物理复习要点.pdf">原子物理复习要点</a>
</template>

<script>
  export default {

  }
</script>
