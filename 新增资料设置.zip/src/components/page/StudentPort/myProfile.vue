<template>
  <div>
    <div class="crumbs">
      <el-breadcrumb separator="/">
        <el-breadcrumb-item><i class="el-icon-date"></i>资料设置</el-breadcrumb-item>
      </el-breadcrumb>
    </div>

    <div class="container">
      <div class="form-box">
        <el-form ref="form" :model="form" label-width="80px">
          <el-form-item label="真实姓名">
            <el-input v-model="form.name"></el-input>
          </el-form-item>

          <el-form-item label="性别">
            <el-radio-group v-model="form.gender">
              <el-radio label="男" value="male"></el-radio>
              <el-radio label="女" value="female"></el-radio>
            </el-radio-group>
          </el-form-item>

          <el-form-item label="年级">
            <el-select v-model="form.Grade" placeholder="请选择">
              <el-option key="1" label="大一" value="1"></el-option>
              <el-option key="2" label="大二" value="2"></el-option>
              <el-option key="3" label="大三" value="3"></el-option>
              <el-option key="4" label="大四" value="4"></el-option>
            </el-select>
          </el-form-item>

          <el-form-item label="所在院系">
            <el-input v-model="form.School"></el-input>
          </el-form-item>

          <el-form-item label="邮箱">
            <el-input v-model="form.mailbox"></el-input>
          </el-form-item>


          <el-form-item>
            <el-button type="primary" @click="onSubmit">表单提交</el-button>
            <el-button>取消</el-button>
          </el-form-item>

        </el-form>
      </div>
    </div>
  </div>
</template>

<script>
  export default {
    name: 'baseform',
    data: function(){
      return {
        form: {
          name:"陈昶金",
          gender:"男",
          Grade:"大二",
          School:"电子科学与技术（23系）",
          mailbox:"chencj@mail.ustc.edu.cn"
        }
      }
    },

    methods: {
      goBack(){
        this.$router.go(-1);
      },
      onSubmit() {
        this.$message.success('提交成功！');
      }
    }
  }
</script>

<style scoped>

</style>
