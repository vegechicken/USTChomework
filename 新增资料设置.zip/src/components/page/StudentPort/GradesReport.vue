<template>

</template>

<script>
    export default {
        name: "GradesReport"
    }
</script>

<style scoped>

</style>
