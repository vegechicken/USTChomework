<template>
  <div>
    <div class="crumbs">
      <el-breadcrumb separator="/">
        <el-breadcrumb-item><i class="el-icon-date"></i>资料设置</el-breadcrumb-item>
      </el-breadcrumb>
    </div>

    <div class="container">
      <div class="form-box">
        <el-form ref="form" :model="form" label-width="80px">
          <el-form-item label="教师姓名">
            <el-input v-model="form.name"></el-input>
          </el-form-item>

          <el-form-item label="性别">
            <el-radio-group v-model="form.gender">
              <el-radio label="男" value="male"></el-radio>
              <el-radio label="女" value="female"></el-radio>
            </el-radio-group>
          </el-form-item>

          <el-form-item label="所在院系">
            <el-input v-model="form.School"></el-input>
          </el-form-item>

          <el-form-item label="办公地址">
            <el-input v-model="form.Office"></el-input>
          </el-form-item>

          <el-form-item label="邮箱">
            <el-input v-model="form.mailbox"></el-input>
          </el-form-item>

          <el-form-item>
            <el-button type="primary" @click="onSubmit">表单提交</el-button>
            <el-button>取消</el-button>
          </el-form-item>

        </el-form>
      </div>
    </div>
  </div>
</template>

<script>
  export default {
    name: 'baseform',
    data: function(){
      return {
        form: {
          name:"陆伟",
          gender:"男",
          Office:"电二楼219室",
          School:"信息学院",
          mailbox:"luwei@ustc.edu.cn",
        }
      }
    },

    methods: {
      goBack(){
        this.$router.go(-1);
      },
      onSubmit() {
        this.$message.success('提交成功！');
      }
    }
  }
</script>

<style scoped>
  .user_photo {
    width: 120px;
    height: 120px;
    border-radius: 50%;
  }

</style>
